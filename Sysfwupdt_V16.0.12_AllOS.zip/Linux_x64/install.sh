#!/bin/bash

DISTRO=`cat /etc/*-release | grep -w "NAME=" | awk '{print $1}' | cut -d '"' -f2`
VERSION=`cat /etc/*-release | grep "VERSION_ID=" | awk '{print $1}' | cut -d '"' -f2`

if [[ $DISTRO =~ .*"Red".* ]]
then
    if [[ "$VERSION" < 9 ]];
    then
        VERSION="8"
    else
        VERSION="9"
    fi
   rpm --import pubKey.asc
   rpm -ivh RHEL/RHEL${VERSION}/*.rpm

elif [[ $DISTRO =~ .*"Cent".* ]]
then
    if [[ "$VERSION" < 8 ]];
    then
       VERSION="7"
    else
       VERSION="8"
    fi
   rpm --import pubKey.asc
   rpm -ivh RHEL/RHEL${VERSION}/*.rpm
   
elif [[ $DISTRO =~ .*"Ubuntu".* ]]
then
    if [[ $VERSION < 22 ]]
    then
       VERSION="20"
    else
       VERSION="22"
    fi
   gpg --import pubKey.asc
   dpkg -i UBUNTU/UBUNTU${VERSION}/*.deb

elif [[ $DISTRO =~ .*"SLES".* ]]
then
    if [[ $VERSION < 15 ]]
    then
       VERSION="12"
    else
       VERSION="15"
    fi

   rpm --import pubKey.asc
   rpm -ivh SLES/SLES${VERSION}/*.rpm

elif [[ $DISTRO =~ .*"SLED".* ]]
then
    if [[ $VERSION < 15 ]]
    then
       VERSION="12"
    else
       VERSION="15"
    fi

   rpm --import pubKey.asc
   rpm -ivh SLES/SLES${VERSION}/*.rpm

else
   echo "OS version is not supported"
   exit 1;
fi

if [ $? = 0 ]
then
   echo "$UTIL_NAME is installed successfully" 
else
   echo "$UTIL_NAME installation is failed" 
fi
